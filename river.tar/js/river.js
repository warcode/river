var River = function() {
	var user = new Object;

	var Init = function() {
		$('#main').html('<div id="river"></div>');
		$('#river').html('<div id="menubox"></div>');
		$('#menubox').html('<div id="write-control" class="write-button"><a href="#">WRITE</a></div><div id="twitter_signin" class="twitter-button"><a href="#" onclick="River.OAuth();"><img src="img/sign-in-with-twitter-gray.png" alt="Sign in with Twitter"></a></div>');
		$('#river').append('<div id="msgbox"></div>');
		$('#msgbox').addClass('hidden');
		$('#write-control').click(function(){
			$('#msgbox').slideToggle(250);
		});
		$('#msgbox').html('<fieldset><textarea name="status" id="status" rows="5" cols="40" class="" placeholder="Your Tweet…" autocomplete="off"></textarea><input type="submit" value="SEND" class="send-button"><div class="characters">140</div></fieldset>');
		$('#status').on('input', function() {
    		var count = 140 - $('#status').val().length;
    		$('.characters').html(count.toString());
		})

		$('#river').append('<div id="stream"></div>');

		
		Login();
	},

	Login = function() {
		 user.login_token = localStorage.getItem('warcode.river.user.login_token');
		 user.hasTwitterAuth = false;
		 console.log(user);

  		$.ajax({
			type: "POST",
			url: "https://deny.io/river/login",
			data: {
				login_token: user.login_token
			},
			dataType: 'json',
			success: function(data, status, jqXHR) {
				if(jqXHR.status === 201) {
					localStorage.setItem('warcode.river.user.login_token', data.login_token);
					user.hasTwitterAuth = data.hasTwitterAuth;
					//$('.twitter-button').hide();
					console.log('created new user - token: %s, twitter: %s', data.login_token, data.hasTwitterAuth);
				} else if(jqXHR.status === 200) {
					user.hasTwitterAuth = data.hasTwitterAuth;
					//$('.twitter-button').hide();
					console.log('existing user - token: %s, twitter: %s', data.login_token, data.hasTwitterAuth);
				} else {
					console.log(jqXHR.status);
				}

				//Timeline();
				Connect();
			}
  		});
	},

	OAuth = function() {
		window.location = 'https://deny.io/river/oauth/login?login_token='+user.login_token;
	},

	Timeline = function() {
		if(user.hasTwitterAuth) {

  			console.log('here');
			$.ajax({
				type: "GET",
				url: "https://deny.io/river/user/timeline",
				data: {
					login_token: user.login_token
				},
				dataType: 'json',
				success: function(data, status, jqXHR) {
					console.log(data);
					Tweet.Add(data);
				}
			});
		}
	},

	Connect = function() {
		if(user.hasTwitterAuth) {

			var socket = io.connect('https://deny.io/river/user/stream/socket');

			socket.on('challenge', function (data) {
					console.log(data);
					socket.emit('rise', {
						socket_id: data.socket_id,
						login_token: user.login_token
					});
			});

			socket.on('rise-accepted', function (data) {
				Stream();
				
				socket.on('tweet', function (data) {
					Tweet.Add(data);
				});

				socket.on('retweet', function (data) {
					Tweet.AddReTweet(data);
				});

				socket.on('delete', function (data) {
					Tweet.Delete(data.delete.status.id_str);
				});
			});
		}
	},

	Stream = function() {
		if(user.hasTwitterAuth) {
			$.ajax({
				type: "GET",
				url: "https://deny.io/river/user/stream",
				data: {
					login_token: user.login_token
				},
				dataType: 'json',
				success: function(data, status, jqXHR) {
					$('#stream').prepend('<br/><div id="stream-start" class="tweet">STREAM STARTED</div>');
				}
			});
		}
	},

	Tweet = function() {
		var counter = 0;

		var Add = function(data) {
			console.log('TWEET')
			console.log(data);

			var data_object;
			if(typeof data === 'string') {
				data_object = JSON.parse(data);	
			} else {
				data_object = data;
			}

			var twitter_data = data_object;
			//console.log(data_object[0]);
			console.log('Created at: %s',twitter_data.created_at);
			$('#stream').prepend('<br/><div id="'+twitter_data.id_str+'" class="tweet hidden"><div class="content"><img class="avatar" src="' + twitter_data.user.profile_image_url_https +'"><div class="user"> '+ twitter_data.user.name +' (<a href="https://twitter.com/'+ twitter_data.user.screen_name +'" target="_new">@'+ twitter_data.user.screen_name +'</a>)</div><div class="message">'+ twttr.txt.autoLink(twitter_data.text) +'</div></div><abbr class="timeago" title="'+ moment(twitter_data.created_at, "ddd MMM DD HH:mm:ss ZZ YYYY").format("ddd MMM DD HH:mm:ss YYYY") +'" data-livestamp="'+ moment(twitter_data.created_at, "ddd MMM DD HH:mm:ss ZZ YYYY").format("X") +'"></abbr></div></div>');
			$('#'+twitter_data.id_str).fadeIn();
		},

		AddReTweet = function(data) {

			var twitter_data = data;
			console.log('RETWEET')
			console.log(data);
			$('#stream').prepend('<br/><div id="'+twitter_data.retweeted_status.id_str+'" class="tweet retweet hidden"><div class="content"><img class="avatar" src="'+ twitter_data.retweeted_status.user.profile_image_url_https +'"><img class="retweeter" src="'+ twitter_data.user.profile_image_url_https +'"><div class="user-retweet"><img src="img/retweet.png"> '+ twitter_data.retweeted_status.user.name +' (<a href="https://twitter.com/'+ twitter_data.retweeted_status.user.screen_name +'" target="_new">@'+ twitter_data.retweeted_status.user.screen_name +'</a>) by <a href="https://twitter.com/'+ twitter_data.user.screen_name +'" target="_new">@'+ twitter_data.user.screen_name +'</a></div><div class="message">'+ twttr.txt.autoLink(twitter_data.retweeted_status.text) +'</div></div><abbr class="timeago" title="'+ moment(twitter_data.created_at, "ddd MMM DD HH:mm:ss ZZ YYYY").format("ddd MMM DD HH:mm:ss YYYY") +'" data-livestamp="'+ moment(twitter_data.created_at, "ddd MMM DD HH:mm:ss ZZ YYYY").format("X") +'"></abbr></div>');
			$('#'+twitter_data.retweeted_status.id_str).fadeIn();
		},
		
		Delete = function(id) {
			$('#'+id).addClass('deleted');
		};

		return {
			Add: Add,
			AddReTweet: AddReTweet,
			Delete: Delete
		};
	}();

	return {
		Init: Init,
		Tweet: Tweet,
		Login: Login,
		OAuth: OAuth,
		Timeline: Timeline,
		Connect: Connect,
		Stream: Stream
	};
}();